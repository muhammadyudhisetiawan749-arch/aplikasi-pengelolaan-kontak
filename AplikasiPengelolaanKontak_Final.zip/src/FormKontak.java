import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FormKontak extends javax.swing.JFrame {
    public FormKontak() {
        initComponents();
        tampilData();
    }

    private void tampilData() {
        DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Nama", "Nomor", "Kategori"}, 0);
        try (Connection conn = Koneksi.getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM kontak");
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"), rs.getString("nama"),
                    rs.getString("nomor"), rs.getString("kategori")
                });
            }
            tabelKontak.setModel(model);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ... (form dan tombol JFrame lainnya seperti pada kode sebelumnya)
}
