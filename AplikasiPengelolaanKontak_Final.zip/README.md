# Aplikasi Pengelolaan Kontak
Nama : Muhammad Yudhi Setiawan  
NPM  : 2110010225  

## Deskripsi
Program ini merupakan aplikasi pengelolaan kontak sederhana berbasis Java (JFrame Form) 
yang dapat menambah, mengubah, menghapus, dan mencari data kontak 
(kolom: Nama, Nomor, dan Kategori).  
Dibuat sebagai latihan mata kuliah Pemrograman Berorientasi Objek 2.

## Cara Menjalankan
1. Buka proyek ini menggunakan NetBeans.
2. Jalankan file `FormKontak.java`.
3. Pastikan file `Koneksi.java` telah dikonfigurasi sesuai database MySQL kamu.
